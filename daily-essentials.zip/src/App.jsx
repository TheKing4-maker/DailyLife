
// src/App.jsx
import React, { useState } from 'react';

const essentials = [
  { id: 1, name: "Toothbrush", category: "Personal Care" },
  { id: 2, name: "Soap", category: "Personal Care" },
  { id: 3, name: "Rice", category: "Groceries" },
  { id: 4, name: "Shampoo", category: "Personal Care" },
  { id: 5, name: "Milk", category: "Groceries" },
  { id: 6, name: "Dish Soap", category: "Household" },
  { id: 7, name: "Toilet Paper", category: "Household" },
  { id: 8, name: "Bread", category: "Groceries" },
  { id: 9, name: "Lotion", category: "Personal Care" },
  { id: 10, name: "Laundry Detergent", category: "Household" },
];

export default function App() {
  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const filteredEssentials = essentials.filter(item => {
    const matchesQuery = item.name.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;
    return matchesQuery && matchesCategory;
  });

  const categories = ["All", "Personal Care", "Groceries", "Household"];

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h1 style={{ textAlign: 'center' }}>Daily Life Essentials</h1>

      <input
        type="text"
        placeholder="Search essentials..."
        value={query}
        onChange={e => setQuery(e.target.value)}
        style={{ width: '100%', padding: 10, fontSize: 16, marginBottom: 20 }}
      />

      <select
        value={categoryFilter}
        onChange={e => setCategoryFilter(e.target.value)}
        style={{ width: '100%', padding: 10, fontSize: 16, marginBottom: 20 }}
      >
        {categories.map(cat => (
          <option key={cat} value={cat}>{cat}</option>
        ))}
      </select>

      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {filteredEssentials.length > 0 ? filteredEssentials.map(item => (
          <li key={item.id} style={{ padding: '10px 0', borderBottom: '1px solid #ddd' }}>
            <strong>{item.name}</strong> <em>({item.category})</em>
          </li>
        )) : (
          <li>No essentials found.</li>
        )}
      </ul>
    </div>
  );
}
