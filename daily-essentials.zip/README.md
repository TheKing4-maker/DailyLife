
# Daily Life Essentials

This React app allows users to search and browse daily life essentials.

## How to deploy to GitHub Pages

1. Fork or clone this repo.
2. Replace `homepage` in `package.json` with your GitHub username and repo name.
3. Run:
   ```
   npm install
   npm run deploy
   ```
4. Your site will be live at `https://yourusername.github.io/daily-essentials`

---

Feel free to customize the essentials list in `src/App.jsx`.
